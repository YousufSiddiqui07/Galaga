import mayflower.*;

public class Animation
{
    private MayflowerImage[] frames;
    private int framerate;
    private int currentFrame;

    public Animation(int ms, String[] filenames)
    {
        currentFrame = 0;
        framerate = ms;

        // Creates MayflowerImage(s) out of filenames
        frames = new MayflowerImage[filenames.length];
        for (int i = 0; i < filenames.length; i++)
        {
            frames[i] = new MayflowerImage(filenames[i]);
        }
    }

    public int getFrameRate()
    {
        return framerate;
    }

    // Gets the next image in the sequence
    public MayflowerImage getNextFrame()
    {
        if (currentFrame >= frames.length)
            currentFrame = 0;

        MayflowerImage nextFrame = frames[currentFrame];
        currentFrame++;

        return nextFrame;
    }

    // Functions to modify images

    // Changes scale of images
    public void scale(int w, int h)
    {
        for (int i = 0; i < frames.length; i++)
            frames[i].scale(w, h);
    }

    // Changes bounds of images
    public void setBounds(int x, int y, int w, int h)
    {
        for (int i = 0; i < frames.length; i++)
            frames[i].crop(x, y, w, h);   
    }

    // Changes transparency of images
    public void setTransparency(int percent)
    {
        for (int i = 0; i < frames.length; i++)
            frames[i].setTransparency(percent);
    }

    // Mirrors images
    public void mirrorHorizontally()
    {
        for (int i = 0; i < frames.length; i++)
            frames[i].mirrorHorizontally();
    }
}
