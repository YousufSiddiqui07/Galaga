import mayflower.*;

public class Block extends Actor
{
    public  Block()
    {
        // Sets image
        setImage("img/2.png");
    }

    public void act()
    {

    }
}
