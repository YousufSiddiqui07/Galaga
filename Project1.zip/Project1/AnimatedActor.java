import mayflower.*;

public class AnimatedActor extends GravityActor
{
    private Animation animation;
    private Timer animationTimer;
    private boolean doAnimations;

    public AnimatedActor(boolean animations)
    {
        // Sets timer between animation frames updating
        animationTimer = new Timer(20000000);

        // Sets if actor should be animated, as moveable actors rely on being animated
        doAnimations = animations;
    }

    public void setAnimation(Animation a)
    {
        animation = a;
    }

    public void act()
    {
        // Gets next image in animation list sets image
        if (doAnimations)
            if (animationTimer.isDone())
            {
                animationTimer.reset();
                MayflowerImage nextFrame = animation.getNextFrame();

                setImage(nextFrame);
            }

        super.act();
    }
}
