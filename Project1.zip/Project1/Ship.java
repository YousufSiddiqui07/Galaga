import mayflower.*;

public class Ship extends GravityActor
{
    // Creates health, direction, and timer variables
    private int health;
    private Timer moveTimer;
    private Timer initialFireTimer;
    private int direction = 1;
    
    public Ship(int type)
    {
        // Sets image based on type of ship given
        MayflowerImage main;
        
        if (type == 1)
            main = new MayflowerImage("img/alien.png");
        else if (type == 2)
            main = new MayflowerImage("img/bee.png");
        else
            main = new MayflowerImage("img/enemy_ship.png");
        
        main.scale(100, 87);
        main.rotate(180);
        
        setImage(main);
        
        // Sets health and timer variables
        health = 5;
        
        moveTimer = new Timer(1000000000);
        initialFireTimer = new Timer(1000000000);
    }
    
    public void act()
    {
        super.act();
        
        // Updates direction of ship if timer is done, resets timer
        if (moveTimer.isDone())
        {
            moveTimer.reset();
            
            direction = direction * -1;
        }
        
        // Fires a random beam
        if(initialFireTimer.isDone() && (int) (Math.random() * 110) == 1)
        {
            getWorld().addObject(new EnemyBeam(-1), getX() - 5 + (int) (Math.random() * 50), getY() + 25);
        }   
        
        // Hurts enemy ship if player beam touches
        if (isTouching(Beam.class))
        {
            Object a = getOneIntersectingObject(Beam.class);
            Beam b = (Beam) a;
            
            health--;
            
            getWorld().removeObject(b);
        }
        
        // Removes object if health is 0
        if (health < 1)
        {
            getWorld().addObject(new Explosion(), getX(), getY());
            getWorld().removeObject(this);
        }
        
        // Updates enemy ship location
        setLocation(getX() - direction, getY());
    }
}