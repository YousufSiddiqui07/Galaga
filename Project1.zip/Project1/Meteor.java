import mayflower.*;

public class Meteor extends Projectile
{
    private int health;

    public Meteor()
    {
        // Sets image
        MayflowerImage img = new MayflowerImage("img/meteor.png");

        // Generates random scale for image
        double scale = Math.random();
        int size = (int) (50 * scale) + 50;

        img.scale(size, size);

        setImage(img);

        // Sets health of object / amount of hits before it explodes
        health = 5;
    }

    public void act()
    {
        super.act();

        // Check if meteor is hit by beam, if so reduce score
        if (isTouching(Beam.class))
        {
            Object a = getOneIntersectingObject(Beam.class);
            Beam b = (Beam) a;

            health--;

            getWorld().removeObject(b);
        }

        // If health is 0 then the object is removed from the world
        if (health < 1)
        {
            getWorld().addObject(new Explosion(), getX(), getY());
            getWorld().removeObject(this);
        }
    }
}
