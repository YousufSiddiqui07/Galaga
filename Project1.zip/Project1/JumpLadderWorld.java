import mayflower.*;

public class JumpLadderWorld extends World {

    private PlayerShip player; 

    private String[][] tiles;

    public JumpLadderWorld() 
    {
        // Mayflower.showBounds(true);

        // Sets background
        MayflowerImage bg = new MayflowerImage("img/basicbg.png");
        bg.scale(800, 600);              
        setBackground(bg);
        tiles = new String[8][6];

        // Adds player and ladders
        tiles[3][4] = "player";

        tiles[6][2] = "ladder";
        tiles[6][3] = "ladder";
        tiles[6][4] = "ladder";

        // Builds world
        addGround();
        buildWorld();
    }

    public void buildWorld()
    {
        // Places actors based on list value
        for (int i = 0; i < tiles.length; i++)
        {
            for (int j = 0; j < tiles[i].length; j++)
            {
                if (tiles[i][j] == "ship")
                {
                    addObject(new Ship(0), i * 100, j * 100);
                }

                if (tiles[i][j] == "player")
                {
                    player = new PlayerShip();
                    addObject(player, i * 100, j * 100);
                }

                if (tiles[i][j] == "ground")
                {
                    addObject(new Block(), i * 100, j * 100);
                }

                if (tiles[i][j] == "ladder")
                {
                    addObject(new Ladder(), i * 100, j * 100);
                }
            }
        }
    }

    public void addGround()
    {
        // Adds tile floor to list
        for (int i = 0; i < tiles.length; i++)
            tiles[i][5] = "ground";
    }

    public void act()
    {
        // Changes world if enter is pressed
        if (Mayflower.isKeyDown(Keyboard.KEY_ENTER))
            Mayflower.setWorld(new TitleScreen());

        // Enables player to jump
        if (player.getX() < 520 && Mayflower.isKeyDown(Keyboard.KEY_UP) && player.getY() > 380)
            player.setLocation(player.getX(), player.getY() - 150);

        if (player.getX() < 520 && player.getY() < 400)
            player.setLocation(player.getX(), player.getY() + 3);
    }
}