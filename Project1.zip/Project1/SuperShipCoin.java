import mayflower.*;

public class SuperShipCoin extends Projectile
{
    public SuperShipCoin()
    {
        // Sets image
        MayflowerImage img = new MayflowerImage("img/supercoin.png");
        img.scale(60, 60);        
        setImage(img);
    }

    public void act()
    {
        super.act();

        // Check if coin touches player, reward player if it does
        if (isTouching(PlayerShip.class))
        {
            Object a = getOneIntersectingObject(PlayerShip.class);
            PlayerShip p = (PlayerShip) a;

            p.setSuperShip();

            getWorld().removeObject(this);
        }
    }
}
