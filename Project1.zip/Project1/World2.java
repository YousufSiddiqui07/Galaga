import mayflower.*;

public class World2 extends World {

    private PlayerShip player;
    private String[][] tiles;
    
    public World2() 
    {
        // Sets background image
        MayflowerImage bg = new MayflowerImage("img/bg2.png");
        bg.scale(800, 600);              
        setBackground(bg);
        
        // Sets up tiles system
        tiles = new String[8][6];
        tiles[3][5] = "player";
        
        // Builds the world and places the ships
        generateShips();
        buildWorld();
    }
    
    public void buildWorld()
    {
        // Places objects based on list values
        for (int i = 0; i < tiles.length; i++)
        {
            for (int j = 0; j < tiles[i].length; j++)
            {
                if (tiles[i][j] == "ship")
                {
                    addObject(new Ship(1), i * 100, j * 100);
                }
                
                if (tiles[i][j] == "player")
                {
                    player = new PlayerShip();
                    addObject(player, i * 100, j * 100);
                }
            }
        }
    }
    
    public void generateShips()
    {
        // Places ships
        
        for (int i = 2; i < tiles.length - 2; i++)
        {
            tiles[i][1] = "ship";
        }
        
        for (int i = 1; i < tiles.length - 1; i++)
        {
            tiles[i][2] = "ship";
        }
    }
    
    public void act()
    {
        // Adds random projectiles
        if ((int) (Math.random() * 20) == 1)
            addObject(new Meteor(), (int) (Math.random() * 200) + 300, -120);
            
        if ((int) (Math.random() * 100) == 1)
            addObject(new Coin(), (int) (Math.random() * 200) + 300, -120);
            
        if ((int) (Math.random() * 1500) == 1)
            addObject(new SuperShipCoin(), (int) (Math.random() * 200) + 300, -120);
                
        // Switches to next world if player score is 5
        if (player.getScore() > 4)
            Mayflower.setWorld(new World3());
    }
    
}