import mayflower.*;

public class PlayerShip extends MovableAnimatedActor
{
    private Animation main_animation;
    private Animation super_animation;

    private Timer beamTimer;

    // Lives and score variables, updated throughout the game
    private int lives;
    private int score;

    public PlayerShip() 
    {        
        super(true);

        // Sets image and main animation
        String[] main_filenames = new String[4];
        for (int i = 0; i < main_filenames.length; i++)
            main_filenames[i] = "img/ship/ship" + i + ".png";

        main_animation = new Animation(50, main_filenames);
        main_animation.scale(100, 87);

        setIdleAnimation(main_animation);

        String[] super_filenames = new String[4];
        for (int i = 0; i < super_filenames.length; i++)
            super_filenames[i] = "img/ship/supership" + i + ".png";

        super_animation = new Animation(50, super_filenames);
        super_animation.scale(100, 87);

        beamTimer = new Timer(100000000);

        // Sets lives and score
        lives = 5;
        score = 0;
    }

    public void updateText()
    {
        // Updates displayed text as game plays
        if (getWorld() != null)
            getWorld().showText("Lives: " + lives + " | Score: " + score, 10, 50);
    }

    // Transforms the ship into Super Ship! Changes image of ship and beam timer
    public void setSuperShip()
    {
        setIdleAnimation(super_animation);
        beamTimer = new Timer(30000000);
    }

    public int getScore()
    {
        return score;
    }

    public void setScore(int s)
    {
        score = s;
    }

    public void act()
    {
        super.act();
        updateText();

        // Produces beam when key is pressed
        if(beamTimer.isDone() && Mayflower.isKeyDown(Keyboard.KEY_UP))
        {
            beamTimer.reset();
            getWorld().addObject(new Beam(1), getX() - 5 + (int) (Math.random() * 50), getY() - 25);
        }

        // Hurts player if meteor hits
        if (isTouching(Meteor.class))
        {
            Object a = getOneIntersectingObject(Meteor.class);
            Meteor m = (Meteor) a;

            lives--;

            getWorld().addObject(new Explosion(), m.getX(), m.getY());
            getWorld().removeObject(m);
        }

        // Hurts player if enemy beam hits
        if (isTouching(EnemyBeam.class))
        {
            Object a = getOneIntersectingObject(EnemyBeam.class);
            EnemyBeam b = (EnemyBeam) a;

            lives--;

            getWorld().removeObject(b);
        }

        // Allows player to climb ladders
        if (isTouching(Ladder.class) && Mayflower.isKeyDown(Keyboard.KEY_UP))
        {
            setLocation(getX(), getY() - 2);
        }

        // Removes player if lives run out
        if (lives < 1)
            Mayflower.setWorld(new DeadScreen());
    }
}
