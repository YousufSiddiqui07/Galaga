import mayflower.*;

public class Ladder extends Actor
{
    public Ladder()
    {
        // Sets and scales image

        MayflowerImage img = new MayflowerImage("img/ladder.png");
        img.scale(100, 100);
        setImage(img);
    }

    public void act()
    {

    }
}
