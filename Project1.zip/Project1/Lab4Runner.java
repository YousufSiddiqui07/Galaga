import mayflower.*;

public class Lab4Runner 
{
    // Runs program
    public static void main(String[] args) 
    {
        new MyMayflower();
    }
} 