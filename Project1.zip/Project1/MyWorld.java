import mayflower.*;

public class MyWorld extends World {

    // Private class variables

    private PlayerShip player;     
    private String[][] tiles;

    public MyWorld() 
    {
        // Sets up background

        MayflowerImage bg = new MayflowerImage("img/bg.png");
        bg.scale(800, 600);              
        setBackground(bg);

        // Sets up tile layout and creates world
        tiles = new String[8][6];
        tiles[3][5] = "player";

        generateShips();
        buildWorld();
    }

    public void buildWorld()
    {
        // Adds objects to world

        for (int i = 0; i < tiles.length; i++)
        {
            for (int j = 0; j < tiles[i].length; j++)
            {
                if (tiles[i][j] == "ship")
                {
                    addObject(new Ship(0), i * 100, j * 100);
                }

                if (tiles[i][j] == "player")
                {
                    player = new PlayerShip();
                    addObject(player, i * 100, j * 100);
                }
            }
        }
    }

    public void generateShips()
    {
        // Adds ships to tile list

        for (int i = 1; i < tiles.length - 1; i++)
        {
            tiles[i][1] = "ship";
        }

        for (int i = 2; i < tiles.length - 2; i++)
        {
            tiles[i][2] = "ship";
        }
    }

    public void act()
    {
        // Adds projectiles at random intervals

        if ((int) (Math.random() * 30) == 1)
            addObject(new Meteor(), (int) (Math.random() * 200) + 300, -120);

        if ((int) (Math.random() * 100) == 1)
            addObject(new Coin(), (int) (Math.random() * 200) + 300, -120);

        if ((int) (Math.random() * 1500) == 1)
            addObject(new SuperShipCoin(), (int) (Math.random() * 200) + 300, -120);

        // Changes world once player score goal is met

        if (player.getScore() > 4)
            Mayflower.setWorld(new World2());
    }

}