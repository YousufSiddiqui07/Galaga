import mayflower.*;

public class Explosion extends AnimatedActor
{
    Timer timer;

    public Explosion()
    {
        super(false);

        // Sets image
        MayflowerImage img = new MayflowerImage("img/explosion.png");
        img.scale(80, 80);
        setImage(img);

        // Sets timer for how long explosion should be up
        timer = new Timer(100000000);

        // Plays explosion sound
        Mayflower.playSound("img/explosion.wav");
    }

    public void act()
    {
        // Removes object once timer is done
        if (timer.isDone())
            getWorld().removeObject(this);        
    }
}
