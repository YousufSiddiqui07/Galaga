import mayflower.*;

public class Beam extends GravityActor
{
    private int direction;
    
    public Beam(int dir) 
    {   
        // Sets image
        MayflowerImage beam = new MayflowerImage("img/beam.png");
        beam.rotate(270);
        beam.scale(50, 50);
        setImage(beam);

        // Sets sound and initial direction
        direction = dir;
                
        Mayflower.playSound("img/beam.wav");
    }
    
    public void act()
    {
        // Updates beam location
        setLocation(getX(), getY() - (direction * 10));
        
        // Removes beam and enemy beam if they collide
        if (isTouching(EnemyBeam.class))
        {
            Object a = getOneIntersectingObject(EnemyBeam.class);
            EnemyBeam b = (EnemyBeam) a;
            
            getWorld().removeObject(b);
            getWorld().removeObject(this);
        }
        
        // Removes object if out of bounds
        if (getY() > 650 || getY() < -50 || getX() > 850 || getX() < -50)
            getWorld().removeObject(this);
    }
}
