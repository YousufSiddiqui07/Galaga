import mayflower.*;

public class EnemyBeam extends GravityActor
{
    private int direction;

    public EnemyBeam(int dir) 
    {   
        // Sets image
        MayflowerImage beam = new MayflowerImage("img/beam2.png");
        beam.rotate(90);
        beam.scale(50, 50);
        setImage(beam);

        // Sets initial direction
        direction = dir;
    }

    public void act()
    {
        // Updates beam location
        setLocation(getX(), getY() - (direction * 10));

        // Removes beam and enemy beam if they collide
        if (isTouching(Beam.class))
        {
            Object a = getOneIntersectingObject(Beam.class);
            Beam b = (Beam) a;

            getWorld().removeObject(b);
            getWorld().removeObject(this);
        }

        // Removes beam if it touches a meteor
        if (isTouching(Meteor.class))
        {
            getWorld().removeObject(this);
        }

        // Removes object if out of bounds
        if (getY() > 650 || getY() < -50 || getX() > 850 || getX() < -50)
            getWorld().removeObject(this);
    }
}