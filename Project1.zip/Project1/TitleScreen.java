
import mayflower.*;

public class TitleScreen extends World
{
    public TitleScreen()
    {
        // Sets background
        MayflowerImage bg = new MayflowerImage("img/title.jpg");
        bg.scale(800, 600);

        setBackground(bg);

        // Text
        showText("PATMOYO", 50, 270, 300, Color.WHITE);
        showText("by Patrick, Mohnish & Yousuf", 20, 260, 330, Color.WHITE);
    }

    public void act()
    {
        // Proceeds to next world once enter is pressed
        if (Mayflower.isKeyDown(Keyboard.KEY_ENTER))
            Mayflower.setWorld(new MyWorld());

        // Proceeds to ladder world if L is pressed
        if (Mayflower.isKeyDown(Keyboard.KEY_L))
            Mayflower.setWorld(new JumpLadderWorld());
    }
}
