import mayflower.*;

public class Coin extends Projectile
{
    public Coin()
    {
        // Sets image
        MayflowerImage img = new MayflowerImage("img/coin.png");
        img.scale(60, 60);        
        setImage(img);
    }

    public void act()
    {
        super.act();

        // Check if coin touches player, reward player if it does
        if (isTouching(PlayerShip.class))
        {
            Object a = getOneIntersectingObject(PlayerShip.class);
            PlayerShip p = (PlayerShip) a;

            p.setScore(p.getScore() + 1);

            getWorld().removeObject(this);
        }
    }
}
