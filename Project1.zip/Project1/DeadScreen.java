import mayflower.*;

public class DeadScreen extends World
{
    public DeadScreen()
    {
        // Sets background
        MayflowerImage bg = new MayflowerImage("img/title.jpg");
        bg.scale(800, 600);

        setBackground(bg);

        // Sets text
        showText("Game over.", 50, 280, 300, Color.WHITE);
        showText("Return to title screen? (SPACE)", 20, 260, 330, Color.WHITE);

        // Plays game over sound
        Mayflower.playSound("img/hush.wav");
    }

    public void act()
    {
        // Goes to title screen if space is pressed
        if (Mayflower.isKeyDown(Keyboard.KEY_SPACE))
            Mayflower.setWorld(new TitleScreen());
    }
}