import mayflower.*;

public class Projectile extends GravityActor
{   
    int direction;
    int speedX, speedY;

    public Projectile()
    {
        // Creates random direction and speed variables

        direction = (int) (Math.random() * 2) == 1 ? -1 : 1;   

        speedX = (int) (Math.random() * 3) + 1;
        speedY = (int) (Math.random() * 3) + speedX + 1;
    }

    public void act()
    {
        // Updates location as the game plays
        setLocation(getX() - direction * speedX, getY() + speedY);

        // Removes projectile if out of bounds
        if (getY() > 800 || getY() < -200 || getX() > 1000 || getX() < -200)
            getWorld().removeObject(this);
    }
}
