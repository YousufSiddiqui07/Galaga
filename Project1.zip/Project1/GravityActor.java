import mayflower.*;

public class GravityActor extends Actor
{
    public void act()
    {
        // Updates gravity. Gravity is disabled in this game, so this class is sort of obsolete, but good to detect blocking/falling

        /* setLocation(getX(), getY() + 1);

        if (isBlocked())
        setLocation(getX(), getY() - 1); */
    }

    // Checks if player is blocked
    public boolean isBlocked()
    {
        return isTouching(Block.class);
    }

    // Checks if player is falling
    public boolean isFalling()
    {
        boolean falling;
        setLocation(getX(), getY() + 1);
        falling = isTouching(Block.class);
        setLocation(getX(), getY() - 1);

        return !falling;
    }
}
